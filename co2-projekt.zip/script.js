// Quiz
const fragen = [
  {
    frage: "Welches Gas ist hauptsächlich für den Klimawandel verantwortlich?",
    antworten: ["CO₂", "Sauerstoff", "Wasserstoff"],
    richtig: 0
  },
  {
    frage: "Welche Fortbewegung verursacht am wenigsten CO₂?",
    antworten: ["Auto", "Fahrrad", "Flugzeug"],
    richtig: 1
  },
  {
    frage: "Welches Lebensmittel hat die höchste CO₂-Bilanz?",
    antworten: ["Rindfleisch", "Tomaten", "Kartoffeln"],
    richtig: 0
  }
];

let aktuelleFrage = 0;

function zeigeFrage() {
  let f = fragen[aktuelleFrage];
  document.getElementById("frage").innerText = f.frage;
  let antwortDiv = document.getElementById("antworten");
  antwortDiv.innerHTML = "";
  f.antworten.forEach((antwort, index) => {
    let btn = document.createElement("button");
    btn.innerText = antwort;
    btn.onclick = () => {
      if (index === f.richtig) {
        document.getElementById("feedback").innerText = "✅ Richtig!";
      } else {
        document.getElementById("feedback").innerText = "❌ Falsch!";
      }
    };
    antwortDiv.appendChild(btn);
  });
}

function naechsteFrage() {
  aktuelleFrage = (aktuelleFrage + 1) % fragen.length;
  document.getElementById("feedback").innerText = "";
  zeigeFrage();
}

zeigeFrage();

// Schätzspiel
function checkSchaetzen() {
  let input = document.getElementById("schaetzung").value;
  let korrekt = 150; // ca. 150 g CO₂ pro km Autofahrt
  let feedback = document.getElementById("schaetzenFeedback");
  if (Math.abs(input - korrekt) <= 30) {
    feedback.innerText = "✅ Gut geschätzt! Ein Auto verursacht ca. 150g CO₂ pro km.";
  } else {
    feedback.innerText = "❌ Nicht ganz. Richtwert: ca. 150g CO₂ pro km Auto.";
  }
}