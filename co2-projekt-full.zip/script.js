// --- Daten (territorial CO2, 2023) ---
// Werte gerundet, Quellen: IEA & Our World in Data (siehe Footer)
const laender = ['China','USA','Indien','EU27','Russland'];
const emissionen = [12.6, 4.8, 2.7, 2.3, 1.7]; // Gigatonnen CO2 (Gt), 2023

// Chart.js Balkendiagramm
const ctx = document.getElementById('barChart').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: laender,
    datasets: [{
      label: 'CO₂-Emissionen 2023 (Gt)',
      data: emissionen,
      backgroundColor: ['#2a5298','#1e90ff','#00a86b','#ffb84d','#d9534f']
    }]
  },
  options: {
    responsive:true,
    plugins:{legend:{display:false}},
    scales:{y:{beginAtZero:true,title:{display:true,text:'Gigatonnen CO₂'}}}
  }
});

// Fakten-Karussell
const fakten = [
  'Wusstest du? China ist 2023 größter CO₂-Emittent (ca. 12.6 Gt).',
  'Wusstest du? Ein durchschnittliches Auto stößt ca. 150 g CO₂ pro km aus.',
  'Wusstest du? Fleisch (vor allem Rind) hat eine hohe CO₂-Bilanz.',
  'Wusstest du? Strom sparen und Ökostrom helfen sofort CO₂ zu reduzieren.'
];
let faktIndex = 0;
const factsDiv = document.getElementById('facts');
function showFakt(){ factsDiv.innerText = fakten[faktIndex]; faktIndex=(faktIndex+1)%fakten.length; }
showFakt();
setInterval(showFakt,4500);

// --- Quiz (Punkte) ---
const fragen = [
  {frage:'Welches Gas verursacht hauptsächlich die menschengemachte Erwärmung?', antworten:['CO₂','Sauerstoff','Stickstoff'], richtig:0},
  {frage:'Welches Land emittiert 2023 am meisten CO₂?', antworten:['USA','China','Indien'], richtig:1},
  {frage:'Welche Fortbewegung verursacht am wenigsten CO₂?', antworten:['Auto','Fahrrad','Flugzeug'], richtig:1},
  {frage:'Welches Lebensmittel hat in der Regel die höchste CO₂-Bilanz?', antworten:['Rindfleisch','Kartoffeln','Reis'], richtig:0},
  {frage:'Ca. wieviel Gramm CO₂ verursacht 1 km Autofahrt pro Person (Durchschnitt)?', antworten:['~50 g','~150 g','~400 g'], richtig:1}
];
let aktuelle = 0;
let score = 0;
function zeigeFrage(){
  const f = fragen[aktuelle];
  document.getElementById('frage').innerText = f.frage;
  const div = document.getElementById('antworten');
  div.innerHTML='';
  f.antworten.forEach((a,i)=>{
    const btn = document.createElement('button');
    btn.innerText = a;
    btn.onclick = ()=>{
      if(i===f.richtig){ document.getElementById('feedback').innerText='✅ Richtig!'; score+=10; }
      else{ document.getElementById('feedback').innerText='❌ Falsch.'; score-=2; }
      document.getElementById('score').innerText = score;
    };
    div.appendChild(btn);
  });
}
function naechsteFrage(){
  aktuelle = (aktuelle+1)%fragen.length;
  document.getElementById('feedback').innerText='';
  zeigeFrage();
}
zeigeFrage();

// Schätzspiel
function checkSchaetzen(){
  const input = Number(document.getElementById('schaetzung').value);
  const korrekt = 150; // g CO2 per km (Richtwert)
  const fb = document.getElementById('schaetzenFeedback');
  if(!input){ fb.innerText='Bitte gib eine Zahl ein.'; return; }
  const diff = Math.abs(input-korrekt);
  if(diff<=20) fb.innerText='✅ Super geschätzt! Richtwert: ~150 g CO₂/km.';
  else if(diff<=60) fb.innerText='👍 Nicht schlecht. Richtwert: ~150 g CO₂/km.';
  else fb.innerText='❌ Das weicht stark ab. Richtwert: ~150 g CO₂/km.';
}
